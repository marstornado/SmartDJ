package com.dartmouth.hackthon.droplist;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.telephony.TelephonyManager;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.provider.Settings.Secure;
import java.io.IOException;
import java.sql.SQLException;

/**
 * Created by libinjie on 4/11/15.
 */

public class StartActivity extends Activity {

    static int groupnumber;
    static DB db;
    static int flag;

    public static DB getDB(){
        return db;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitAll().build());

        final Button join_button = (Button) findViewById(R.id.join_button);
        final Button create_button = (Button) findViewById(R.id.create_button);

        join_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Perform action on click
                AlertDialog.Builder dialog = new AlertDialog.Builder(StartActivity.this);
                final EditText input = new EditText(StartActivity.this);
                input.setMaxLines(1);
                input.setHint("please enter the group number");
                input.setInputType(InputType.TYPE_CLASS_NUMBER);
                dialog.setView(input);
                //dialog.setIcon(android.R.drawable.btn_star_big_on);
                dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        groupnumber = Integer.parseInt(input.getText().toString());
                        if(isGroup(groupnumber)){
                            //join group database operation
                            try {
                                db = new DB();
                                db.initializeConnection();
                                TelephonyManager tm = (TelephonyManager) getBaseContext().getSystemService(Context.TELEPHONY_SERVICE);
                                db.insertIntoUser(tm.toString(), groupnumber);
                                flag = 1;
                            } catch (IOException e) {
                                e.printStackTrace();
                            } catch (ClassNotFoundException e) {
                                e.printStackTrace();
                            } catch (SQLException e) {
                                e.printStackTrace();
                            }
//                            new Thread(new Runnable() {
//                                public void run(){
//                                    try {
//                                        db = new DB();
//                                        db.initializeConnection();
//                                        db.insertIntoUser("joinuser", groupnumber);
//                                        flag = 1;
//                                    } catch (IOException e) {
//                                        e.printStackTrace();
//                                    } catch (ClassNotFoundException e) {
//                                        e.printStackTrace();
//                                    } catch (SQLException e) {
//                                        e.printStackTrace();
//                                    }
//                                }
//                            }).start();
                            Intent intent = new Intent();
                            intent.setClass(StartActivity.this, ListActivity.class);
                            StartActivity.this.startActivity(intent);
                            StartActivity.this.finish();
                        }else{
                            Toast.makeText(getApplicationContext(), "No Group Found",Toast.LENGTH_SHORT).show();
                            dialog.cancel();
                        }
                    }
                }).setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }).create();
                dialog.show();

            }
        });

        create_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Perform action on click
                // Perform action on click
                AlertDialog.Builder dialog = new AlertDialog.Builder(StartActivity.this);
                final EditText input = new EditText(StartActivity.this);
                input.setMaxLines(1);
                input.setHint("please enter the desired group name");
                dialog.setView(input);
                //dialog.setIcon(android.R.drawable.btn_star_big_on);
                dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final String name = input.getText().toString();
                        if(name.length() >= 5){
                            //insert group number
                            try {
                                db = new DB();
                                db.initializeConnection();
                                TelephonyManager tm = (TelephonyManager) getBaseContext().getSystemService(Context.TELEPHONY_SERVICE);
                                groupnumber = db.getMaxGroupId() + 1;
                                String display = "Your Group Number is "+groupnumber;
                                Toast.makeText(getApplicationContext(),display,Toast.LENGTH_LONG).show();
                                db.insertIntoGroup(groupnumber, name);
                                db.insertIntoUser(tm.toString(), groupnumber);
                                flag = 1;
                            } catch (IOException e) {
                                e.printStackTrace();
                            } catch (ClassNotFoundException e) {
                                e.printStackTrace();
                            } catch (SQLException e) {
                                e.printStackTrace();
                            }
                            Intent intent = new Intent();
                            intent.setClass(StartActivity.this, ListActivity.class);
                            StartActivity.this.startActivity(intent);
                            StartActivity.this.finish();
                        }else{
                            Toast.makeText(getApplicationContext(), "please enter a longer name",Toast.LENGTH_SHORT).show();
                        }
                    }
                }).setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }).create();
                dialog.show();
            }
        });
    }

    private boolean isGroup(int number) {
            return true;
    }
}
