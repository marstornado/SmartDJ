package com.dartmouth.hackthon.droplist;

import android.content.Context;
import android.widget.MediaController;

/**
 * Created by libinjie on 4/11/15.
 */

public class MusicController extends MediaController {

	public MusicController(Context c){
		super(c);
	}

	public void hide(){}

}
