/*
  dbexample.java
  Ira Ray Jenkins

  This simple example demonstrates connecting to a MySQL database and
  executing a query.
 */
package com.dartmouth.hackthon.droplist;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import java.math.*;

public class DB {

    private static Statement stmt = null;
    private static String table_prefix = "iamlbj_db.";

    private int getGroupIdFromUserId(String userId) throws SQLException {
        String query = "SELECT gId from " + table_prefix + "user" + " WHERE usrId == " + userId;
        ResultSet res = stmt.executeQuery(query);
        if (res.next()) {
            return  Integer.parseInt(String.valueOf(res.getObject(1)));
        }
        return 0;
    }

    public void initializeConnection() throws IOException, ClassNotFoundException, SQLException {
        // load mysql driver
        Class.forName("com.mysql.jdbc.Driver");

        // initialize connection
        Connection con = DriverManager.getConnection("jdbc:mysql://sunapee.cs.dartmouth.edu/", "iamlbj", "910911");


        System.out.println("Connection established.");

        // initialize a query statement
        stmt = con.createStatement();
    }

    public int getMaxGroupId() throws SQLException {
        String query = "SELECT max(gId) from " + table_prefix + "group;";
        ResultSet res = stmt.executeQuery(query);

        if (res.next()) {
            System.out.println("fuck, I am here!\n");
            Object a = res.getObject(1);
            if (a == null) return 0;
            String tmpt = String.valueOf(a);
            return Integer.parseInt(tmpt);
//            return Integer.parseInt(String.valueOf(res.getObject(1)));
        }
        return 0;
    }

    public void insertIntoGroup(int groupId, String groupName) throws SQLException {
        String query = "INSERT INTO " + table_prefix + "group" +
                " VALUES (" + groupId + ", " + "\"" + groupName + "\"" +");";
        stmt.executeUpdate(query);
        createTable(groupId);
    }

    public void insertIntoUser(String userId, int groupId) throws SQLException {
        String query = "INSERT INTO " + table_prefix + "user " +
                "VALUES(" + "\"" + userId + "\"" + ", " + groupId + ");";
        stmt.executeUpdate(query);
    }

    private void createTable(int groupID) throws SQLException {
        String query = "CREATE TABLE "+ table_prefix + groupID +
                "(ID numeric(11,0) not null primary key, " +
                "TIMEORDER numeric(10,6) not null, " +
                "NAME char(100) not null, " +
                "ARTIST char(100) not null, " +
                "USERID char(50)); ";
        stmt.executeUpdate(query);
    }

    public ArrayList<Song> getWholeTable(int groupId) throws SQLException {
        ArrayList<Song> l = new ArrayList<Song>();
        String query = "SELECT * from " + table_prefix + groupId +
                " ORDER BY TIMEORDER ASC;";
        //query = "SELECT * from iamlbj_db.TT2";
        //       "ORDER BY";
        ResultSet res = stmt.executeQuery(query);

//        // the result set contains metadata
        //       int numColumns = res.getMetaData().getColumnCount();
//        for(int i = 1; i <= numColumns; i++) {
//            System.out.format("%-12s", res.getMetaData().getColumnName(i));
//        }
//        System.out.println("\n--------------------------------------------");

        // iterate through results
        while(res.next()) {
            Object tmpt = res.getObject(1);
            if (tmpt == null) return l;
//            for(int i = 1; i <= numColumns; i++) {
//                System.out.format("%-12s", res.getObject(i));
//            }
            l.add(new Song(Long.parseLong(String.valueOf(res.getObject(1))), String.valueOf(res.getObject(3)),
                    String.valueOf(res.getObject(4))));
            System.out.println();
        }

        return l;
    }

    public String getFirstUserId(int groupId) throws SQLException {
        String firstUserId = null;
        String query = "SELECT USERID from " + table_prefix + groupId + " ORDER BY TIMEORDER ASC;";
        ResultSet res = stmt.executeQuery(query);
        while (res.next()) {
            Object tmpt = res.getObject(1);
            if (tmpt == null) return firstUserId;
            return (String) res.getObject(1);
        }
        return firstUserId;
    }


    public void addOneSong(Song s1, int groupId, String userId) throws SQLException {
        String query = "SELECT max(TIMEORDER) from " + table_prefix + groupId + ";";
        ResultSet res = stmt.executeQuery(query);
        BigDecimal timeorder = new BigDecimal(0);
        if (res.next())
        //System.out.printf("%s", res.getObject(1));
        {
            Object tmpt = res.getObject(1);
            if (tmpt != null)
                timeorder = new BigDecimal((String) res.getObject(1));
        }


        query = "INSERT into " + table_prefix + groupId + "(ID, TIMEORDER, NAME, ARTIST, USERID) values(" +
                String.valueOf(s1.getID()) + ", " +String.valueOf(timeorder.add(new BigDecimal(1))) +
                ", \"" + s1.getTitle() + "\", \"" + s1.getArtist() + "\"" + ", "+ "\"" + userId +
                "\"" +")"+";";

        stmt.executeUpdate(query);
    }

    public void deleteOneSong(int groupId, Song s) throws SQLException {
        //int groupId = getGroupIdFromUserId(userId);
        String query = "DELETE FROM " + table_prefix + groupId + " WHERE ID = " + String.valueOf(s.getID());
        stmt.executeUpdate(query);
    }

    public void changeOrder(int groupId, Song s1, Song s2, Song s) throws SQLException {
        BigDecimal timeOrderS1 = new BigDecimal(0), timeOrderS2 = new BigDecimal(0), newTimeOrder;
        //int groupId = getGroupIdFromUserId(userId);

        // get the time order of song s1
        String query = "SELECT TIMEORDER from " + table_prefix + groupId + " WHERE ID = " + s1.getID();
        ResultSet res = stmt.executeQuery(query);
        res.next();
        timeOrderS1 = (BigDecimal)(res.getObject(1));

        // get the time order of song s2
        query = "SELECT TIMEORDER from " + table_prefix + groupId + " WHERE ID = " + s2.getID();
        res = stmt.executeQuery(query);
        res.next();
        timeOrderS2 = (BigDecimal)(res.getObject(1));

        newTimeOrder = timeOrderS1.add(timeOrderS2).divide(new BigDecimal(2));

        // update the time order of song s
        query = "UPDATE " + table_prefix + groupId + " SET TIMEORDER = " + String.valueOf(newTimeOrder) +
                "WHERE ID = " + s.getID();
        stmt.executeUpdate(query);
    }

    public void quit(String userId, int groupId) throws SQLException {
        String query = null;
        // modify the user table
        query = "DELETE FROM " + table_prefix + "user" + " WHERE userId = " + "\"" + userId + "\"";
        stmt.executeUpdate(query);

        // modify the gid table
        query = "DELETE FROM " + table_prefix + groupId + " WHERE USERID = " + "\"" + userId + "\"";
        stmt.executeUpdate(query);
    }


}

